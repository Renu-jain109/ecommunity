import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-OWIEUP6K.js";
import "./chunk-3DGWSFJU.js";
import "./chunk-HHATRTCI.js";
import "./chunk-DTKMHGSD.js";
import "./chunk-JRME76AQ.js";
import "./chunk-J2FQWUXU.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-WVJ2LAEC.js";
import "./chunk-WDMUDEB6.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
