export const environment = {
    API_URL : "http://localhost:8086"
};
