import { UserpipePipe } from './userpipe.pipe';

describe('UserpipePipe', () => {
  it('create an instance', () => {
    const pipe = new UserpipePipe();
    expect(pipe).toBeTruthy();
  });
});
